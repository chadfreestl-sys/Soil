TURFARIUM — 32 SEASONAL IMAGE PACK

CONTENTS
  images/seasons/spring/state-01-stressed.webp ... state-08-elite.webp
  images/seasons/summer/state-01-stressed.webp ... state-08-elite.webp
  images/seasons/fall/state-01-stressed.webp ... state-08-elite.webp
  images/seasons/winter/state-01-stressed.webp ... state-08-elite.webp

INSTALL VIA GITHUB:
  1. Upload the ZIP AS-IS into the root of the chadfreestl-sys/Soil repo on main.
     Exact filename: turfarium-seasonal-32.zip
  2. Commit the upload.
  3. The installed .github/workflows/install-seasonal-images.yml action extracts
     the 32 files to images/seasons/, verifies them and commits them into main.
     It removes the ZIP from main to avoid storing a second copy.
  4. The Turfarium seasonal engine detects spring/summer/fall/winter by month
     and visual health state. The existing images are the fallback until assets exist.

These images are illustrative photorealistic artwork, not field-validated agronomic forecasts.
